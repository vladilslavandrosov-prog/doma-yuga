# 🏡 Дома Юга — Клиентский портал

Строительная компания. React + Express + PostgreSQL + Drizzle ORM.

## Страницы

| URL | Описание |
|-----|----------|
| `/` | Главная — лендинг с услугами, портфолио, CTA |
| `/contact` | Анкета обратной связи (3 шага) |
| `/admin` | CRM-панель для просмотра заявок |

## Быстрый старт на Replit

1. **Форкни** репозиторий в Replit (Import from GitHub)
2. В **Tools → Database** создай PostgreSQL базу — `DATABASE_URL` подставится автоматически
3. В **Secrets** при необходимости задай `ADMIN_KEY` (по умолчанию `admin123`)
4. Нажми **Run** — сервер стартует на порту 5000
5. Создай таблицы: в Shell выполни `npm run db:push`

## Команды

```bash
npm run dev      # dev-режим (server + vite)
npm run build    # сборка продакшн
npm start        # запуск продакшн
npm run db:push  # создать/обновить таблицы в БД
npm run db:studio # Drizzle Studio — GUI для БД
```

## API

| Метод | URL | Описание |
|-------|-----|----------|
| `POST` | `/api/leads` | Создать заявку |
| `GET` | `/api/leads` | Список заявок (заголовок `x-admin-key`) |
| `PATCH` | `/api/leads/:id` | Обновить статус/заметки |

## Структура

```
├── client/src/
│   ├── pages/
│   │   ├── home.tsx      ← Главная страница
│   │   ├── contact.tsx   ← Анкета заявки
│   │   └── admin.tsx     ← CRM-панель
│   ├── lib/
│   │   └── queryClient.ts
│   └── App.tsx
├── server/
│   ├── index.ts    ← Express сервер
│   ├── routes.ts   ← API роуты
│   ├── storage.ts  ← Работа с БД
│   └── db.ts       ← Подключение к PostgreSQL
├── shared/
│   └── schema.ts   ← Drizzle схема (таблица leads)
└── .replit
```

## Переменные окружения (Replit Secrets)

| Переменная | Описание | По умолчанию |
|-----------|----------|--------------|
| `DATABASE_URL` | PostgreSQL строка подключения | авто (Replit DB) |
| `ADMIN_KEY` | Ключ доступа к /admin | `admin123` |
| `PORT` | Порт сервера | `5000` |
