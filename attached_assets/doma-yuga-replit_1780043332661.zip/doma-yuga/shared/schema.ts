import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  services:       text("services").notNull(),          // JSON: ["build","repair",...]
  objectType:     text("object_type"),
  area:           integer("area"),
  budget:         text("budget"),
  timeline:       text("timeline"),
  city:           text("city"),
  description:    text("description"),
  name:           text("name").notNull(),
  phone:          text("phone").notNull(),
  email:          text("email"),
  contactMethods: text("contact_methods").notNull(),   // JSON
  callTimes:      text("call_times"),                  // JSON
  source:         text("source"),
  status:         text("status").default("new").notNull(), // new|called|working|done|declined
  notes:          text("notes"),
  createdAt:      timestamp("created_at").defaultNow().notNull(),
});

export const insertLeadSchema = createInsertSchema(leads).omit({
  id: true, createdAt: true, status: true, notes: true,
});

export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;
