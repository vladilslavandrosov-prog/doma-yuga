import type { Express, Request, Response } from "express";
import { createLead, getLeads, updateLeadStatus } from "./storage";
import { insertLeadSchema } from "../shared/schema";
import { ZodError } from "zod";

const ADMIN_KEY = process.env.ADMIN_KEY || "admin123"; // override in Replit Secrets

export function registerRoutes(app: Express) {

  // POST /api/leads  —  submit contact form
  app.post("/api/leads", async (req: Request, res: Response) => {
    try {
      const data = insertLeadSchema.parse(req.body);
      const lead = await createLead(data);
      return res.status(201).json({ ok: true, id: lead.id });
    } catch (e) {
      if (e instanceof ZodError) {
        return res.status(400).json({ ok: false, errors: e.errors });
      }
      console.error("create lead error:", e);
      return res.status(500).json({ ok: false, message: "Внутренняя ошибка" });
    }
  });

  // GET /api/leads  —  admin: list all leads
  app.get("/api/leads", async (req: Request, res: Response) => {
    if (req.headers["x-admin-key"] !== ADMIN_KEY) {
      return res.status(401).json({ ok: false, message: "Unauthorized" });
    }
    const all = await getLeads();
    return res.json(all);
  });

  // PATCH /api/leads/:id  —  admin: update status / notes
  app.patch("/api/leads/:id", async (req: Request, res: Response) => {
    if (req.headers["x-admin-key"] !== ADMIN_KEY) {
      return res.status(401).json({ ok: false, message: "Unauthorized" });
    }
    const id = Number(req.params.id);
    const { status, notes } = req.body;
    if (!status) return res.status(400).json({ ok: false, message: "status required" });
    const lead = await updateLeadStatus(id, status, notes);
    return res.json(lead);
  });
}
