import { db } from "./db";
import { leads, type InsertLead, type Lead } from "../shared/schema";
import { eq, desc } from "drizzle-orm";

export async function createLead(data: InsertLead): Promise<Lead> {
  const [lead] = await db.insert(leads).values(data).returning();
  return lead;
}

export async function getLeads(): Promise<Lead[]> {
  return db.select().from(leads).orderBy(desc(leads.createdAt));
}

export async function updateLeadStatus(
  id: number,
  status: string,
  notes?: string
): Promise<Lead> {
  const [lead] = await db
    .update(leads)
    .set({ status, ...(notes !== undefined ? { notes } : {}) })
    .where(eq(leads.id, id))
    .returning();
  return lead;
}
