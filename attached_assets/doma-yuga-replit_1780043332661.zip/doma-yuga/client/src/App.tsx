import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import HomePage    from "./pages/home";
import ContactPage from "./pages/contact";
import AdminPage   from "./pages/admin";

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Switch>
        <Route path="/"        component={HomePage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/admin"   component={AdminPage} />
        <Route>
          <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
            fontFamily:"sans-serif", flexDirection:"column", gap:12 }}>
            <div style={{ fontSize:48 }}>🏠</div>
            <h1>404 — страница не найдена</h1>
            <a href="/" style={{ color:"#C17F3A" }}>← На главную</a>
          </div>
        </Route>
      </Switch>
    </QueryClientProvider>
  );
}
