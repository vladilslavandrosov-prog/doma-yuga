import { Link } from "wouter";
import { useEffect, useRef, useState } from "react";

// ─── Animated counter ────────────────────────────────────────────────────────
function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        obs.disconnect();
        let start = 0;
        const step = Math.ceil(to / 60);
        const timer = setInterval(() => {
          start = Math.min(start + step, to);
          setVal(start);
          if (start >= to) clearInterval(timer);
        }, 20);
      },
      { threshold: 0.3 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [to]);
  return <span ref={ref}>{val}{suffix}</span>;
}

// ─── Data ─────────────────────────────────────────────────────────────────────
const SERVICES = [
  {
    icon: "🏠",
    title: "Строительство домов",
    desc: "Проекты любой сложности «под ключ» — от закладки фундамента до финальной отделки.",
    items: ["Каркасные дома", "Кирпич и газобетон", "Дома из бруса", "Монолитное строительство"],
  },
  {
    icon: "🔧",
    title: "Ремонт и реконструкция",
    desc: "Капитальный ремонт, перепланировка, реставрация фасадов и несущих конструкций.",
    items: ["Перепланировка", "Фасадные работы", "Кровля и утепление", "Укрепление фундамента"],
  },
  {
    icon: "🖌️",
    title: "Отделочные работы",
    desc: "Черновая и чистовая отделка. Работаем с любыми материалами и стилями.",
    items: ["Черновая отделка", "Чистовая отделка", "Дизайн-проект", "Ландшафт и благоустройство"],
  },
  {
    icon: "📐",
    title: "Проектирование",
    desc: "Разработка архитектурных и инженерных проектов, согласование в госорганах.",
    items: ["Архитектурный проект", "Инженерные сети", "Сметная документация", "Сопровождение в ГСН"],
  },
];

const PROJECTS = [
  { title: "Коттедж 180 м²", place: "Краснодар", tag: "Под ключ", color: "#2C3E2D" },
  { title: "Таунхаус 240 м²", place: "Сочи", tag: "Строительство", color: "#C17F3A" },
  { title: "Ремонт квартиры", place: "Ростов-на-Дону", tag: "Отделка", color: "#4A7C6B" },
  { title: "Загородный дом 320 м²", place: "Анапа", tag: "Под ключ", color: "#8B5E3C" },
  { title: "Коммерческое здание", place: "Краснодар", tag: "Реконструкция", color: "#2C3E2D" },
  { title: "Дача 90 м²", place: "Геленджик", tag: "Строительство", color: "#C17F3A" },
];

const WHY_US = [
  { icon: "🏆", title: "25+ лет опыта", desc: "Работаем с 2000 года. Знаем все тонкости строительства на юге России." },
  { icon: "📋", title: "Фиксированная смета", desc: "Цена прописывается в договоре и не меняется в ходе работ." },
  { icon: "⚡", title: "Соблюдение сроков", desc: "Штрафные санкции за просрочку — в договоре. Мы не опаздываем." },
  { icon: "🛡️", title: "Гарантия 3 года", desc: "Официальная гарантия на конструктив, кровлю и отделочные работы." },
  { icon: "👷", title: "Собственная бригада", desc: "Только штатные мастера — без субподряда и непроверенных рабочих." },
  { icon: "📸", title: "Фотоотчёт онлайн", desc: "Ежедневные отчёты о ходе работ в вашем личном кабинете." },
];

// ─── Component ────────────────────────────────────────────────────────────────
export default function HomePage() {
  return (
    <div style={{ fontFamily: "'Geologica', 'Segoe UI', sans-serif", color: "#1A1A1A" }}>

      {/* ── NAV ── */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: "rgba(28,50,35,0.97)", backdropFilter: "blur(8px)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 5%", height: 64,
      }}>
        <span style={{ color: "#fff", fontWeight: 700, fontSize: 20, letterSpacing: "-.02em" }}>
          🏡 <span style={{ color: "#C17F3A" }}>Дома</span> Юга
        </span>
        <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
          {[["Услуги", "#services"], ["Проекты", "#projects"], ["О нас", "#why"]].map(([l, h]) => (
            <a key={l} href={h} style={{ color: "rgba(255,255,255,.7)", textDecoration: "none", fontSize: 14, fontWeight: 500 }}
              onMouseEnter={e => (e.currentTarget.style.color = "#fff")}
              onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,.7)")}>
              {l}
            </a>
          ))}
          <Link href="/contact">
            <span style={{
              background: "#C17F3A", color: "#fff", padding: "8px 20px",
              borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer",
              textDecoration: "none", whiteSpace: "nowrap",
            }}>
              Оставить заявку
            </span>
          </Link>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section style={{
        minHeight: "100vh", background: "linear-gradient(135deg, #1B3A2D 0%, #2C4A38 50%, #1A2E20 100%)",
        display: "flex", flexDirection: "column", justifyContent: "center",
        padding: "120px 5% 80px", position: "relative", overflow: "hidden",
      }}>
        {/* Decorative circles */}
        {[
          { w: 500, h: 500, top: -100, right: -100, op: 0.06 },
          { w: 300, h: 300, top: "40%", right: "15%", op: 0.04 },
          { w: 200, h: 200, bottom: 50, left: "10%", op: 0.05 },
        ].map((c, i) => (
          <div key={i} style={{
            position: "absolute", width: c.w, height: c.h,
            top: c.top, right: c.right, bottom: (c as any).bottom, left: (c as any).left,
            borderRadius: "50%", border: `1px solid rgba(193,127,58,${c.op * 5})`,
            background: `rgba(193,127,58,${c.op})`, pointerEvents: "none",
          }} />
        ))}

        <div style={{ maxWidth: 760, position: "relative" }}>
          <div style={{
            display: "inline-block", background: "rgba(193,127,58,.15)",
            border: "1px solid rgba(193,127,58,.4)", borderRadius: 50,
            padding: "6px 16px", marginBottom: 24,
          }}>
            <span style={{ color: "#C17F3A", fontSize: 13, fontWeight: 600 }}>
              ✦ Краснодарский край и вся Россия
            </span>
          </div>

          <h1 style={{
            fontSize: "clamp(36px,6vw,68px)", fontWeight: 700, color: "#fff",
            lineHeight: 1.1, marginBottom: 24, letterSpacing: "-.03em",
          }}>
            Строим дома,<br />
            <span style={{ color: "#C17F3A" }}>которыми гордятся</span>
          </h1>

          <p style={{ fontSize: "clamp(15px,2vw,18px)", color: "rgba(255,255,255,.7)", lineHeight: 1.7, marginBottom: 40, maxWidth: 560 }}>
            Полный цикл строительства и отделки — от проекта до ключей. Более 500 объектов сданы в срок за 25 лет работы.
          </p>

          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <Link href="/contact">
              <span style={{
                background: "#C17F3A", color: "#fff", padding: "14px 32px",
                borderRadius: 10, fontSize: 16, fontWeight: 700, cursor: "pointer",
                textDecoration: "none", display: "inline-block",
                boxShadow: "0 8px 32px rgba(193,127,58,.35)",
              }}>
                Получить расчёт бесплатно →
              </span>
            </Link>
            <a href="tel:+78001234567" style={{
              background: "rgba(255,255,255,.08)", color: "#fff", padding: "14px 24px",
              borderRadius: 10, fontSize: 16, fontWeight: 500, cursor: "pointer",
              textDecoration: "none", border: "1px solid rgba(255,255,255,.15)",
            }}>
              📞 +7 (800) 123-45-67
            </a>
          </div>
        </div>

        {/* Stats bar */}
        <div style={{
          display: "flex", gap: 2, marginTop: 72, flexWrap: "wrap",
        }}>
          {[
            { n: 25, s: "+", label: "лет на рынке" },
            { n: 500, s: "+", label: "объектов сдано" },
            { n: 70, s: "+", label: "клиентов" },
            { n: 98, s: "%", label: "довольных заказчиков" },
          ].map(({ n, s, label }, i) => (
            <div key={i} style={{
              background: "rgba(255,255,255,.07)", border: "1px solid rgba(255,255,255,.1)",
              borderRadius: 12, padding: "20px 28px", flex: "1 1 160px",
            }}>
              <div style={{ fontSize: 36, fontWeight: 800, color: "#C17F3A", lineHeight: 1 }}>
                <Counter to={n} suffix={s} />
              </div>
              <div style={{ color: "rgba(255,255,255,.55)", fontSize: 13, marginTop: 6 }}>{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section id="services" style={{ padding: "96px 5%", background: "#F7F4EF" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <p style={{ color: "#C17F3A", fontWeight: 700, fontSize: 13, letterSpacing: ".12em", textTransform: "uppercase", marginBottom: 10 }}>
            Что мы делаем
          </p>
          <h2 style={{ fontSize: "clamp(28px,4vw,44px)", fontWeight: 700, marginBottom: 56, letterSpacing: "-.03em" }}>
            Полный спектр услуг
          </h2>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px,1fr))", gap: 20 }}>
            {SERVICES.map((svc) => (
              <div key={svc.title} style={{
                background: "#fff", borderRadius: 16, padding: "2rem",
                border: "1px solid #E8E2D8",
                transition: "transform .2s, box-shadow .2s",
              }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = "translateY(-4px)";
                  e.currentTarget.style.boxShadow = "0 16px 48px rgba(0,0,0,.08)";
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = "";
                  e.currentTarget.style.boxShadow = "";
                }}>
                <div style={{ fontSize: 36, marginBottom: 16 }}>{svc.icon}</div>
                <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 10 }}>{svc.title}</h3>
                <p style={{ color: "#6B6B6B", fontSize: 14, lineHeight: 1.6, marginBottom: 20 }}>{svc.desc}</p>
                <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
                  {svc.items.map((item) => (
                    <li key={item} style={{ fontSize: 13, color: "#4A7C6B", padding: "3px 0", display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ color: "#C17F3A" }}>✓</span> {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PROJECTS ── */}
      <section id="projects" style={{ padding: "96px 5%", background: "#fff" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <p style={{ color: "#C17F3A", fontWeight: 700, fontSize: 13, letterSpacing: ".12em", textTransform: "uppercase", marginBottom: 10 }}>
            Портфолио
          </p>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 48, flexWrap: "wrap", gap: 16 }}>
            <h2 style={{ fontSize: "clamp(28px,4vw,44px)", fontWeight: 700, letterSpacing: "-.03em" }}>
              Реализованные объекты
            </h2>
            <Link href="/contact">
              <span style={{ color: "#C17F3A", fontWeight: 600, fontSize: 15, cursor: "pointer", textDecoration: "none" }}>
                Заказать похожий →
              </span>
            </Link>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px,1fr))", gap: 16 }}>
            {PROJECTS.map((p) => (
              <div key={p.title} style={{
                borderRadius: 14, overflow: "hidden",
                border: "1px solid #E8E2D8",
                transition: "transform .2s",
              }}
                onMouseEnter={e => e.currentTarget.style.transform = "scale(1.01)"}
                onMouseLeave={e => e.currentTarget.style.transform = ""}>
                {/* Placeholder image */}
                <div style={{
                  height: 180, background: `linear-gradient(135deg, ${p.color} 0%, ${p.color}CC 100%)`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 48,
                }}>
                  🏠
                </div>
                <div style={{ padding: "1.25rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                    <h3 style={{ fontWeight: 600, fontSize: 16 }}>{p.title}</h3>
                    <span style={{
                      background: "#F5EAD8", color: "#8B5E3C", fontSize: 11, fontWeight: 700,
                      padding: "3px 10px", borderRadius: 50, letterSpacing: ".04em",
                    }}>
                      {p.tag}
                    </span>
                  </div>
                  <p style={{ color: "#6B6B6B", fontSize: 13 }}>📍 {p.place}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY US ── */}
      <section id="why" style={{ padding: "96px 5%", background: "#1B3A2D" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <p style={{ color: "#C17F3A", fontWeight: 700, fontSize: 13, letterSpacing: ".12em", textTransform: "uppercase", marginBottom: 10 }}>
            Почему мы
          </p>
          <h2 style={{ fontSize: "clamp(28px,4vw,44px)", fontWeight: 700, color: "#fff", marginBottom: 56, letterSpacing: "-.03em" }}>
            6 причин выбрать Дома Юга
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px,1fr))", gap: 20 }}>
            {WHY_US.map((w) => (
              <div key={w.title} style={{
                background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.1)",
                borderRadius: 14, padding: "1.75rem",
              }}>
                <div style={{ fontSize: 30, marginBottom: 14 }}>{w.icon}</div>
                <h3 style={{ fontSize: 17, fontWeight: 700, color: "#fff", marginBottom: 8 }}>{w.title}</h3>
                <p style={{ color: "rgba(255,255,255,.6)", fontSize: 14, lineHeight: 1.6 }}>{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section style={{
        padding: "80px 5%",
        background: "linear-gradient(135deg, #C17F3A 0%, #A86E2E 100%)",
        textAlign: "center",
      }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <h2 style={{ fontSize: "clamp(26px,4vw,42px)", fontWeight: 700, color: "#fff", marginBottom: 16, letterSpacing: "-.03em" }}>
            Готовы начать строительство?
          </h2>
          <p style={{ color: "rgba(255,255,255,.8)", fontSize: 17, marginBottom: 36, lineHeight: 1.6 }}>
            Оставьте заявку — бесплатно выедем, замерим, составим смету
          </p>
          <Link href="/contact">
            <span style={{
              background: "#fff", color: "#8B5E3C", padding: "15px 36px",
              borderRadius: 10, fontSize: 16, fontWeight: 700, cursor: "pointer",
              textDecoration: "none", display: "inline-block",
              boxShadow: "0 8px 32px rgba(0,0,0,.15)",
            }}>
              Оставить заявку бесплатно →
            </span>
          </Link>
          <p style={{ color: "rgba(255,255,255,.6)", fontSize: 13, marginTop: 20 }}>
            Ответим в течение часа в рабочее время
          </p>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{
        background: "#111", color: "rgba(255,255,255,.5)",
        padding: "40px 5%", display: "flex", flexWrap: "wrap",
        gap: 24, justifyContent: "space-between", alignItems: "center",
      }}>
        <div>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 18, marginBottom: 6 }}>
            🏡 <span style={{ color: "#C17F3A" }}>Дома</span> Юга
          </div>
          <div style={{ fontSize: 13 }}>Строительная компания с 2000 года</div>
        </div>
        <div style={{ fontSize: 13, textAlign: "right" }}>
          <div><a href="tel:+78001234567" style={{ color: "rgba(255,255,255,.7)", textDecoration: "none" }}>+7 (800) 123-45-67</a></div>
          <div><a href="mailto:info@domayuga.ru" style={{ color: "rgba(255,255,255,.7)", textDecoration: "none" }}>info@домаюга.рф</a></div>
          <div style={{ marginTop: 6 }}>© 2025 Дома Юга. Все права защищены.</div>
        </div>
      </footer>

    </div>
  );
}
