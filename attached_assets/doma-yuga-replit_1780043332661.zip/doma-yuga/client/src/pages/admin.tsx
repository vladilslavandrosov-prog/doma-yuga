import { useState, useEffect } from "react";
import type { Lead } from "../../../shared/schema";

const ADMIN_KEY = "admin123"; // change in Replit → Secrets: ADMIN_KEY

const STATUS_COLORS: Record<string, string> = {
  new:      "#E3F0FF",
  called:   "#FFF8E1",
  working:  "#E8F5E9",
  done:     "#F3E5F5",
  declined: "#FFEBEE",
};
const STATUS_TEXT: Record<string, string> = {
  new:      "🆕 Новая",
  called:   "📞 Позвонили",
  working:  "🔨 В работе",
  done:     "✅ Готово",
  declined: "❌ Отказ",
};

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("ru-RU", { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" });

const parseJ = (s: string | null) => {
  try { return s ? JSON.parse(s) : []; } catch { return []; }
};

export default function AdminPage() {
  const [key, setKey]       = useState("");
  const [authed, setAuthed] = useState(false);
  const [leads, setLeads]   = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Lead | null>(null);
  const [filter, setFilter] = useState("all");
  const [notes, setNotes]   = useState("");
  const [saving, setSaving] = useState(false);

  const login = () => {
    if (key === ADMIN_KEY) { setAuthed(true); loadLeads(key); }
    else alert("Неверный ключ");
  };

  const loadLeads = async (k = key) => {
    setLoading(true);
    try {
      const res = await fetch("/api/leads", { headers: { "x-admin-key": k } });
      if (!res.ok) throw new Error();
      setLeads(await res.json());
    } catch { alert("Ошибка загрузки"); }
    finally { setLoading(false); }
  };

  const updateStatus = async (id: number, status: string, n?: string) => {
    setSaving(true);
    try {
      await fetch(`/api/leads/${id}`, {
        method: "PATCH",
        headers: { "Content-Type":"application/json", "x-admin-key": key },
        body: JSON.stringify({ status, notes: n }),
      });
      await loadLeads();
      setSelected(prev => prev ? { ...prev, status, notes: n ?? prev.notes } : null);
    } catch { alert("Ошибка сохранения"); }
    finally { setSaving(false); }
  };

  useEffect(() => { if (selected) setNotes(selected.notes ?? ""); }, [selected]);

  const filtered = filter === "all" ? leads : leads.filter(l => l.status === filter);

  // ── Login screen ──
  if (!authed) return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
      background:"#F7F4EF", fontFamily:"'Geologica','Segoe UI',sans-serif" }}>
      <div style={{ background:"#fff", padding:"3rem", borderRadius:16, boxShadow:"0 8px 48px rgba(0,0,0,.08)", maxWidth:360, width:"100%" }}>
        <div style={{ fontSize:32, marginBottom:8 }}>🔐</div>
        <h1 style={{ fontWeight:700, fontSize:22, marginBottom:6 }}>Панель лидов</h1>
        <p style={{ color:"#888", fontSize:14, marginBottom:24 }}>Введите ключ доступа</p>
        <input
          type="password"
          placeholder="Ключ доступа"
          value={key}
          onChange={e=>setKey(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&login()}
          style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #DDD8CF", borderRadius:8,
            fontSize:15, fontFamily:"inherit", outline:"none", marginBottom:12 }}
        />
        <button onClick={login} style={{ width:"100%", padding:"12px", background:"#1B3A2D", color:"#fff",
          border:"none", borderRadius:8, fontSize:15, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
          Войти
        </button>
      </div>
    </div>
  );

  // ── Main admin panel ──
  return (
    <div style={{ fontFamily:"'Geologica','Segoe UI',sans-serif", minHeight:"100vh", background:"#F7F4EF" }}>
      {/* Header */}
      <div style={{ background:"#1B3A2D", padding:"0 5%", height:60, display:"flex", alignItems:"center",
        justifyContent:"space-between" }}>
        <span style={{ color:"#fff", fontWeight:700, fontSize:18 }}>
          🏡 Дома Юга — <span style={{ color:"#C17F3A" }}>CRM</span>
        </span>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          <span style={{ color:"rgba(255,255,255,.6)", fontSize:13 }}>Лидов: {leads.length}</span>
          <button onClick={()=>loadLeads()}
            style={{ background:"rgba(255,255,255,.1)", color:"#fff", border:"none", borderRadius:6,
              padding:"6px 14px", fontSize:13, cursor:"pointer", fontFamily:"inherit" }}>
            🔄 Обновить
          </button>
        </div>
      </div>

      <div style={{ display:"flex", height:"calc(100vh - 60px)" }}>
        {/* ── Lead list ── */}
        <div style={{ width:400, flexShrink:0, overflow:"auto", borderRight:"1px solid #DDD8CF", background:"#fff" }}>
          {/* Filters */}
          <div style={{ padding:"12px 16px", borderBottom:"1px solid #EEE8DF", display:"flex", gap:6, flexWrap:"wrap" }}>
            {["all","new","called","working","done","declined"].map(f => (
              <button key={f} onClick={()=>setFilter(f)}
                style={{ padding:"4px 12px", borderRadius:50, fontSize:12, fontWeight:600, cursor:"pointer",
                  border:"1px solid #DDD8CF", fontFamily:"inherit",
                  background: filter===f ? "#1B3A2D" : "transparent",
                  color: filter===f ? "#fff" : "#888" }}>
                {f === "all" ? "Все" : STATUS_TEXT[f]}
              </button>
            ))}
          </div>

          {loading && <div style={{ padding:"2rem", textAlign:"center", color:"#888" }}>Загрузка...</div>}
          {filtered.length === 0 && !loading && (
            <div style={{ padding:"2rem", textAlign:"center", color:"#888" }}>Нет лидов</div>
          )}

          {filtered.map(lead => (
            <div key={lead.id}
              onClick={() => setSelected(lead)}
              style={{ padding:"1rem 1.25rem", borderBottom:"1px solid #EEE8DF", cursor:"pointer",
                background: selected?.id === lead.id ? "#FDF5E8" : "transparent",
                borderLeft: selected?.id === lead.id ? "3px solid #C17F3A" : "3px solid transparent",
                transition:"background .15s" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4 }}>
                <span style={{ fontWeight:600, fontSize:15 }}>{lead.name}</span>
                <span style={{ fontSize:11, padding:"2px 8px", borderRadius:50, fontWeight:600,
                  background: STATUS_COLORS[lead.status], color:"#555" }}>
                  {STATUS_TEXT[lead.status]}
                </span>
              </div>
              <div style={{ fontSize:13, color:"#888" }}>{lead.phone}</div>
              <div style={{ fontSize:12, color:"#aaa", marginTop:3, display:"flex", gap:8 }}>
                <span>{lead.city || "—"}</span>
                <span>·</span>
                <span>{fmt(String(lead.createdAt))}</span>
              </div>
              <div style={{ marginTop:6, display:"flex", gap:4, flexWrap:"wrap" }}>
                {parseJ(lead.services).map((sv: string) => (
                  <span key={sv} style={{ fontSize:10, background:"#F0EDE8", padding:"2px 8px",
                    borderRadius:50, color:"#8B5E3C", fontWeight:600 }}>{sv}</span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* ── Lead detail ── */}
        {selected ? (
          <div style={{ flex:1, overflow:"auto", padding:"2rem" }}>
            <div style={{ maxWidth:600 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"1.5rem" }}>
                <h2 style={{ fontWeight:700, fontSize:22 }}>{selected.name}</h2>
                <button onClick={()=>setSelected(null)} style={{ background:"none", border:"none", fontSize:20, cursor:"pointer" }}>✕</button>
              </div>

              {/* Info grid */}
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:24 }}>
                {[
                  ["📞 Телефон", selected.phone],
                  ["✉️ Email", selected.email || "—"],
                  ["🏙 Город", selected.city || "—"],
                  ["📐 Площадь", selected.area ? `${selected.area} м²` : "—"],
                  ["💰 Бюджет", selected.budget || "—"],
                  ["⏱ Сроки", selected.timeline || "—"],
                  ["🏠 Тип объекта", selected.objectType || "—"],
                  ["📣 Источник", selected.source || "—"],
                ].map(([lbl, val]) => (
                  <div key={lbl} style={{ background:"#fff", borderRadius:10, padding:"12px 16px", border:"1px solid #EEE8DF" }}>
                    <div style={{ fontSize:12, color:"#888", marginBottom:3 }}>{lbl}</div>
                    <div style={{ fontWeight:600, fontSize:14 }}>{val}</div>
                  </div>
                ))}
              </div>

              {/* Tags */}
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:13, color:"#888", marginBottom:6 }}>Услуги</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {parseJ(selected.services).map((sv: string) => (
                    <span key={sv} style={{ background:"#F5EAD8", color:"#8B5E3C", padding:"4px 12px",
                      borderRadius:50, fontSize:13, fontWeight:600 }}>{sv}</span>
                  ))}
                </div>
              </div>

              {/* Contact prefs */}
              <div style={{ marginBottom:16 }}>
                <div style={{ fontSize:13, color:"#888", marginBottom:6 }}>Способ связи / время</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  {[...parseJ(selected.contactMethods), ...parseJ(selected.callTimes)].map((v: string) => (
                    <span key={v} style={{ background:"#E8F0EE", color:"#2C4A38", padding:"4px 12px",
                      borderRadius:50, fontSize:12, fontWeight:600 }}>{v}</span>
                  ))}
                </div>
              </div>

              {/* Description */}
              {selected.description && (
                <div style={{ background:"#fff", border:"1px solid #EEE8DF", borderRadius:10, padding:"1rem 1.25rem", marginBottom:16 }}>
                  <div style={{ fontSize:12, color:"#888", marginBottom:6 }}>Описание проекта</div>
                  <p style={{ fontSize:14, lineHeight:1.6 }}>{selected.description}</p>
                </div>
              )}

              {/* Status */}
              <div style={{ background:"#fff", border:"1px solid #EEE8DF", borderRadius:10, padding:"1.25rem", marginBottom:16 }}>
                <div style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>Статус заявки</div>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                  {Object.entries(STATUS_TEXT).map(([k,v]) => (
                    <button key={k}
                      onClick={()=>updateStatus(selected.id, k, notes)}
                      style={{ padding:"7px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer",
                        border:"1.5px solid",
                        borderColor: selected.status===k ? "#1B3A2D" : "#DDD8CF",
                        background: selected.status===k ? "#1B3A2D" : "transparent",
                        color: selected.status===k ? "#fff" : "#555",
                        fontFamily:"inherit" }}>
                      {v}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div style={{ background:"#fff", border:"1px solid #EEE8DF", borderRadius:10, padding:"1.25rem" }}>
                <div style={{ fontSize:13, fontWeight:600, marginBottom:8 }}>Заметки менеджера</div>
                <textarea value={notes} onChange={e=>setNotes(e.target.value)}
                  placeholder="Добавьте комментарий..."
                  style={{ width:"100%", minHeight:80, padding:"10px 12px", border:"1.5px solid #DDD8CF",
                    borderRadius:8, fontSize:14, fontFamily:"inherit", outline:"none", resize:"vertical" }} />
                <button onClick={()=>updateStatus(selected.id, selected.status, notes)} disabled={saving}
                  style={{ marginTop:10, padding:"9px 20px", background:"#1B3A2D", color:"#fff",
                    border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
                  {saving ? "Сохранение..." : "💾 Сохранить заметку"}
                </button>
              </div>

              <div style={{ fontSize:12, color:"#aaa", marginTop:12 }}>
                Заявка #{selected.id} · {fmt(String(selected.createdAt))}
              </div>
            </div>
          </div>
        ) : (
          <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", color:"#aaa", flexDirection:"column", gap:10 }}>
            <div style={{ fontSize:40 }}>👈</div>
            <div style={{ fontSize:15 }}>Выберите заявку из списка</div>
          </div>
        )}
      </div>
    </div>
  );
}
